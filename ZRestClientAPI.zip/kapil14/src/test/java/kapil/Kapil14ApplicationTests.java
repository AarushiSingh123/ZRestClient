package kapil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Kapil14ApplicationTests {

	@Test
	void contextLoads() {
	}

}
