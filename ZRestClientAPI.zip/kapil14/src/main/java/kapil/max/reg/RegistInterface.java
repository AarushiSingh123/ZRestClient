package kapil.max.reg;

import org.springframework.data.repository.CrudRepository;

public interface RegistInterface extends CrudRepository<RegistDTOEntity, Integer>{

	
	
}
