package kapil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Kapil14Application {

	public static void main(String[] args) {
		SpringApplication.run(Kapil14Application.class, args);
	}

}
